#!/bin/bash
# CS 6250 Summer 2021 - SDN Firewall Project with POX
# build frodo-v21

# This file will start the Mininet topology.  IF you see an error stating 
# Unable to Contact Remote Controller, then you have an issue with your implementation
# in sdn-firewall.py.

sudo python sdn-topology.py